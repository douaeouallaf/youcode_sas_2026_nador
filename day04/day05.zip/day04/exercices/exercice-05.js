/**
 * ─────────────────────────────────────────────────────────────
 * JOUR 04 · EXERCICE 05 · NIVEAU 1 : FONDATIONS (DÉBUTANTS)
 * CHERCHER UNE VALEUR (INCLUDES)
 * ─────────────────────────────────────────────────────────────
 *
 * 🎯 MISSION
 * Vérifiez si "Marrakech" est présent dans le tableau villes = ["Rabat", "Casablanca", "Tanger"]. Affichez true ou false.
 *
 * 📖 Consigne détaillée : ../03-exercices.md#exercice-05
 * ▶️ Commande : node day04/exercices/exercice-05.js
 */
'use strict';

// 1. Identifie les données nécessaires.
// 2. Écris ta solution sous cette ligne.
// TODO: écris ta solution ici.
